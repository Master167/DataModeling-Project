/**
 * Entry point for program
 * @author Sean Domingo, Michael Frederick, Megan Molumby, Mai Huong Nguyen, Richard Pratt
 */

public class TSQLEngine {
    public static void main(String[] args) {
        DataEngine db = new DataEngine();
        db.runEngine();
    }
}
