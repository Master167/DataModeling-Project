public class LoadDatabase extends SQLCommand {
    public LoadDatabase(String databaseName) {
        super(databaseName);
    }
    
    @Override
    public void executeCommand() {
    }
}