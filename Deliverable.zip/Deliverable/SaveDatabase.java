/**
 * SaveDatabase
 * @author Sean Domingo, Michael Frederick, Megan Molumby, Mai Huong Nguyen, Richard Pratt
 */
public class SaveDatabase extends SQLCommand {
    public SaveDatabase(String databaseName) {
        super(databaseName);
    }
    
    @Override
    public void executeCommand() {
    }
}